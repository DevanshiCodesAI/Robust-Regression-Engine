ROBUST REGRESSION ENGINE - README ASSET PACK

This ZIP contains the visual files used by README.md.

How to upload on GitHub:
1. Open your repository and select the main branch.
2. Create an assets folder by creating a file named assets/.gitkeep.
3. Open the assets folder and choose Add file -> Upload files.
4. Upload every file from this ZIP's assets folder.
5. Keep every filename exactly the same so the README links work.

The files are:
- robust-regression-pipeline.gif
- model-comparison.gif
- notebook_feature_importance.png
- notebook_ridge_lasso_coefficients.png
- notebook_actual_vs_predicted.png

The PDF guide is a separate root-level file:
Robust_Regression_Theory_Guide.pdf
